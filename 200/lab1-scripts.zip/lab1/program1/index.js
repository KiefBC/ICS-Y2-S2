/*
 * Student: Kiefer Hay
 * Student Number: C0391884
 * Title: Introduction to NodeJS
 * Program: Goblin Hello World
 * Reference: Gobbo's Tales of the Goblin Hello World
 */

console.log("Hello Goblin!");